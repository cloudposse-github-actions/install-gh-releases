#include "wasmer.h"

#pragma message "The wasmer_wasm.h header file is being deprecated, please use wasmer.h instead."
